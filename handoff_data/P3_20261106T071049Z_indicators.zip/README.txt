InfraVista P3 indicator outputs
Run ID: 20261106T071049Z_indicators

Contents:
- indicators_grid.geojson: grid-level indicator records
- indicators_window.geojson: study-window-level indicator records
- manifest.json: run configuration, provenance, checksums and status

Input: handoff_data/20261104T092142Z_publish.zip
Processing CRS: EPSG:32643 (proposed, not approved)
Output CRS: EPSG:4326
Validation: P6 independent review pending
Rights: review_required; team use only

These are derived pilot outputs, not an approved or complete
infrastructure inventory. See the P3 handoff and methods documents.
