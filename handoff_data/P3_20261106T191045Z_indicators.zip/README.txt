﻿InfraVista P3 indicator outputs
Run ID: 20261106T191045Z_indicators

Contents:
- indicators_grid.geojson: latest corrected grid-level indicator records
- indicators_window.geojson: latest corrected study-window indicator records
- manifest.json: run configuration, provenance, checksums and status

Input: handoff_data/20261104T092142Z_publish.zip
Processing CRS: EPSG:32643 (proposed, not approved)
Output CRS: EPSG:4326
Validation: P6 independent review pending
Rights: ODbL rights review required; team use only
OSM completeness: unverified

These are derived pilot outputs, not an approved or complete
infrastructure inventory. See docs/handoffs/P3-P1P5P6-001.md
and reports/p3_qa/20261106T191045Z_indicators/ for QA evidence and limitations.
